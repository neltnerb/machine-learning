US EPA DSSTox DATA RELEASE OCTOBER 2015

DSSTox BACKGROUND:

DSSTox is an effort to collect and curate chemical information from across the web 
with a special focus on chemicals and substances of interest to the EPA.  Curation 
effort is focused on ensuring accurate linkage of substance identifiers (names and 
registry numbers) with structural identifiers (SMILES and InChI).   

FIELDS (short description):

	1) "DSSTox_Substance_Id" � immutable, unique identifier (string) for a DSSTox Substance
	2) "DSSTox_Structure_Id" � immutable, unique identifier (string) for a DSSTox Structure
	3) "DSSTox_QC-Level" - classification (string) of the level of confidence in the data for this substance record
	4) "Substance_Name" � uniquely assigned DSSTox preferred name (string) for the substance
	5) "Substance_CASRN" � uniquely assigned Chemical Abstracts Service Registry Number (string) for the substance
	6) "Substance_Type" - classification (string) of the type of chemical substance
	7) "Substance_Note" - free text field containing additional information regarding the substance
	8) "Structure_SMILES" - SMILES string representation of the structure
	9) "Structure_InChI" - InChI string representation of the structure
	10) "Structure_InChIKey - InChIKey string representation of the structure
	11) "Structure_Formula" - empirical formula (string) of the structure
	12) "Structure_MolWt" - molar mass of the structure

Addition information providing further documentation of DSSTox Standard Fields is below...

DSSTox_Substance_Id:

This field contains the immutable identifier for a unique substance.  This identifier 
is assigned at the time of new substance registration and is intended to always remain 
true to the original source-substance. For example, if the substance was originally 
registered to document a chemical in ToxCast, this substance identifier would always 
document the generic substance in ToxCast.  If a conflict is subsequently discovered 
within the substance information, this dsstox_substance_id would remain associated with 
information thought to best represent the original ToxCast chemical, with the newly 
associated details moved to a new substance record.  

DSSTox_Structure_Id:

This field contains the dsstox immutable identifier for a unique structure.  It is currently 
maintained by registering a new DSSTox Structure record with a new id if a new structure (as detected 
by a new InChIKey) is stored.  The DSSTox_Substance_Id and DSSTox_Structure_Id are in a 
1:1 relationship.  However, any particular relationship is mutable if further curation shows that 
the substance:structure linkage is inaccurate, in which case a new mapping is created.  
This field is left blank if no structure accurately represents a substance.

DSSTox_QC-Level: 

This field contains one of the 7 levels currently in use in DSSTox.  Those levels are as follows:

1) DSSTox_High - Manually curated and considered to be of very high quality based on primary trusted sources
	2) DSSTox_Low - Manually curated and unconflicted in available public sources
	3) Public_High - Programmatically gathered and unconflicted in at least 2 trusted sources
	4) Public_Medium - Programmatically gathered and unconflicted in at least 2 sources (1 of which is considered trusted)
	5) Public_Low - Programmatically gathered, unconflicted, but not from a trusted source
	6) Public_Untrusted - Found to be conflicted in available sources
	7) Incomplete

In the context of these levels, conflicted indicates a record where the name or CASRN is associated 
with a different structure, or where a preferred name is associated with multiple CASRN in different 
sources.  Trusted is a term indicating that a source has been found to usually provide reliable 
structural and substance information by DSSTox curators.
  
Substance_Name:

This field contains a unique substance preferred name for the chemical substance.  
This name is chosen both for accuracy and usability.

Substance_CASRN:

This field contains the unique substance CASRN that DSSTox curators have determined most likely to be the 
assigned current CASRN based on review of public sources.

Substance_Type:

This field contains one of a small number of classes that DSSTox curators use to describe the substance.  
A listing of acceptable values follows:

	1) "Single Compound" - a fully defined single chemical
	2) "Mixture of Stereoisomers" - a set of chemicals which all have the same connectivity, but different chirality
	3) "Mixture/Formulation" - a set of partially defined chemicals
	4) "Macromolecule" - a substance containing a large molecule not normally described in molfile format (e.g., enzymes, antibodies, etc.)
	5) "Polymer" - a substance containing repeating units connected in a defined way with undefined molecular formula, or poly-organics.
	6) "Mineral/Composite" � naturally occurring inorganic substances or composite materials
	7) "Unspecified/Multiple Forms" � a generalized version of a chemical intended by the source to encompass multiple specific salt or stereo forms

Structure_SMILES:

A string field containing a SMILES representation of the structure.  If the field has the value "FAIL", 
a SMILES cannot accurately represent the uniquely defined structure of the chemical.
