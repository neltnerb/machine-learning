US EPA TOXCAST DATA RELEASE OCTOBER 2015

The current ToxCastRelease file contains all chemicals with released assay data in toxcast or tox21.  The file
conforms to the recently updated DSSTox_v2 database in which no "representative" structures are allowed that would 
violate the 1:1 substance (GSID) to structure (CID) mapping rule. The SDF is generated in v3000 format (supported by
ChemAxon Marvin) in order to capture stereochemical distinctions and may not be compatible with some user 
applications. The file can be converted to the older v2000 format, or the SMILES provided in the 
Excel file can be used to circumvent this issue (a SMILES value of �FAIL� indicates a structure incompatible with v2000).

INCLUDED DATAFILES:

	1) "DSSTox_ToxCastRelease_20151019.xlsx" - DSSTox standard xlsx sheet
	2) "DSSTox_ToxCastRelease_20151019.sdf" - DSSTox standard sdf formatted data
	3) "TOX21IDs_v4b_23Oct2014_QCdetails.xlsx" - TOX21 QC FILE providing purity information for tox21 samples

INCLUDED DSSTox STANDARD FIELDS (in DSSTox Standard Files):

ToxCast_chid 		(chemical identifier for mapping to assay data)
DSSTox_Substance_Id
DSSTox_Structure_Id
DSSTox_QC-Level
Substance_Name		
Substance_CASRN		
Substance_Type		
Substance_Note		
Structure_SMILES
Structure_InChI	
Structure_InChIKey
Structure_Formula	
Structure_MolWt


For definitions and details of original DSSTox Standard Chemical Fields, see the included DSSTox_Standard_ReadMe.txt


TOX21 QC FILE:

Tox21ID file containing Tox21 stock solution-level codes (Tox21IDs) linked to ToxCast_chid
values, PubChem substance ID (PUBCHEM_SID), and summarized analytical QC results from the Tox21 
testing program (QC_Grade; QC_Grade_Description).

Tox21ID - sample 
ToxCast_chid
QC_Grade
QC_Grade_Description
PUBCHEM_SID

For the purpose of this data release, a summary "QC_Grade" is listed, with further details provided in
"QC_Grade_Description" as indicated below:

QC_Grade	QC_Grade_Description
Pass		Purity>90% and MW confirmed
		Purity>50% and MW confirmed
		Purity >75% and MW confirmed
Pass MW		MW confirmed, no purity info
Caution		Low purity or concentration
		No sample detected
Not determined	Analysis in progress
		Sample withdrawn
		Unsuitable for analysis
		
